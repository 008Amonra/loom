# 📧 Email & Telegram Agent – Setup-Dokumentation

> **Bonus für Kunden** – Fertig konfigurierter AI-Mail-Assistent für opencode
>
> Stand: Mai 2026 | Autor: Jace

---

## 🚀 Was dieses Package kann

| Feature | Status |
|---|---|
| **E-Mails senden** von bis zu 3 Gmail-Konten | ✅ |
| **E-Mails lesen** per IMAP (letzte 50) | ✅ |
| **Telegram-Bot** senden & empfangen | ✅ |
| **Credentials verschlüsselt** (AES-256-GCM, Passphrase nur im RAM) | ✅ |
| **Passphrase unsichtbar** (`read -s`, keine Plaintext-Logs) | ✅ |

---

## 📁 Dateien

| Datei | Zweck |
|---|---|
| `email-agent/credentials.html` | Browser-Maske: Gmail-Konten eintragen, verschlüsselt exportieren |
| `email-agent/email-credentials.enc.json` | AES-256-verschlüsselte Credentials (wird vom Browser exportiert) |
| `email-agent/mcp-email.mjs` | MCP-Server: E-Mails senden & lesen |
| `email-agent/mcp-telegram.mjs` | MCP-Server: Telegram-Bot senden & empfangen |
| `email-agent/mail.sh` | Starter: fragt Passphrase unsichtbar, startet opencode |
| `email-agent/email-tool.js` | CLI-Tool für E-Mail (Fallback) |

---

## 🔧 Einrichtung (für Kunden)

### 1. Gmail-Konten vorbereiten

Pro Gmail-Konto ein **App-Passwort** erstellen:

- https://myaccount.google.com/apppasswords
- 16-stelliges Passwort generieren (z.B. `xxxx xxxx xxxx xxxx`)

### 2. Credentials verschlüsseln

- `email-agent/credentials.html` im Browser öffnen
- Kontodaten + App-Passwörter eintragen
- Passphrase wählen → **"Verschlüsseln & Speichern"** → Export
- `email-credentials.enc.json` ins `email-agent/`-Verzeichnis legen

### 3. Telegram-Bot erstellen

- In Telegram: `@BotFather` → `/newbot`
- Bot-Namen + Username vergeben → Token kopieren
- In `~/.opencode/opencode.json` unter `telegram` → `TG_BOT_TOKEN` eintragen
- Bot anschreiben (`/start`) → Chat-ID automatisch auslesen
- In `TG_ALLOWED_IDS` eintragen

### 4. opencode starten

```bash
~/email-agent/mail.sh
# → Passphrase blind eintippen
# → opencode startet mit Email- + Telegram-MCP
```

---

## 🎮 Verwendung

### E-Mails senden

```
Schick eine Mail an max@example.com von "Gmail 1"
Betreff: Angebot
Text: Hallo Max, ...
```

### E-Mails lesen

```
Zeig mir die letzten 5 Mails von "Gmail 2 (Bot)"
```

### Telegram

```
Schick via Telegram: "Bin in 10 Minuten da"
Hast du neue Telegram-Nachrichten?
```

---

## 🔒 Sicherheit

- **Credentials** sind AES-256-GCM-verschlüsselt (PBKDF2, 600.000 Iterationen)
- **Passphrase** wird nie gespeichert – nur `read -s` im Terminal
- **MCP-Server** decrypted nur im RAM pro Tool-Call, verwirft danach
- **Bot-Token** liegt in opencode.json (mit `{env:...}`-Syntax auslagerbar)
- Keine Logs mit Klartext-Passwörtern

---

## 📦 Technik-Stack

- **opencode** (AI-Client)
- **Node.js 22+** (MCP-Server, nodemailer, imap)
- **Telegram Bot API** (HTTP, kein SDK)
- **Web Crypto API** (clientseitige Verschlüsselung im Browser)
- **keepassxc-cli** (optional, falls KeePass-DB genutzt wird)

---
